//Andrew Bevilacqua CS202-1001
//Project_1 Names
#include <iostream>
#include <fstream>
const int numNames = 10;//10 names in the list
const int letters = 9; //Maximum 8 letters +1 for NULL
using namespace std;
void getNames(char fileName[],char Name[numNames][letters]);
void printNames(char Names[numNames][letters],int order[numNames]);
int myStringLength(const char str[]);
int myStringCompare(const char str1[],const char str2[]);
void myStringCopy(char dest[],char source[]);
//Sorts names based on length   uses myStringLength/myStringCopy
void sortLength(char Names[numNames][letters],int order[numNames]);
//Sorts names alphabetically    uses myStringCompare/myStringCopy
void sortAlpha(char Names[numNames][letters],int order[numNames]);
//Outputs names in a length file and alphabetical file
void output2File(char Names[numNames][letters],int order[numNames],char outputFile[]);
int main()
{
	char Names[numNames][letters],fileInput[100],fileLen[100],fileAlpha[100];
	int order[]={0,1,2,3,4,5,6,7,8,9};
	cout << "Enter an input file to evaluate:";
	cin >> fileInput;
	cout << "Enter an output file for the names sorted by length:";
	cin >> fileLen;
	cout << "Enter an output file for he names sorted by Alphabetical order:";
	cin >> fileAlpha;
	cout <<endl;
	cout << "Unsorted Data (Original Input Order and Name)"<<endl;
	cout << "=========================="<< endl;
	getNames(fileInput,Names);
	printNames(Names,order);
	cout << "Sorted-by-Length Data (Original Input Order and Name)"<<endl;
	cout << "=========================="<< endl;
	sortLength(Names,order);
	printNames(Names,order);
	output2File(Names,order,fileLen);
	cout << "Alphabetically Sorted Data (Original Input Order and Name)"<<endl;
	cout << "=========================="<< endl;
	sortAlpha(Names, order);
	printNames(Names,order);
	output2File(Names,order,fileAlpha);
	return 0;
}
void getNames(char fileName[],char Names[numNames][letters])
{
	ifstream fp;
	fp.open(fileName);
	while(!fp.eof())
	{
		for(int r=0;r<=numNames-1;r++)
		{
			for(int c=0;c<=letters-1;c++)
			{
				fp.get(Names[r][c]);
				if(Names[r][c]=='\n')
				{
					break;
				}
			}
		}
	}
	fp.close();
}
void printNames(char Names[numNames][letters],int order[numNames])
{
	for(int r=0;r<=numNames-1;r++)
	{
		cout << order[r]<<": ";
		for(int c=0;c<=letters-1;c++)
		{
			cout<< Names[r][c];
		}
		
	}
}
int myStringLength(const char str[])
{
	int i=0;
	for(i;str[i]!='\0';i++)
	{
	}
	return i;
}
int myStringCompare(const char str1[],const char str2[])
{
	for(int i=0;i<=numNames;i++)
	{
		if(str1[i]>str2[i])
			return -1;
		else if(str1[i]<str2[i])
			return 1;
		else if(str1[i]==str2[i])
			return 0;
	}
}
void myStringCopy(char dest[],char source[])
{
	for (int i=0;source[i]!='\0';i++)
	{
		dest[i]=source[i];
	}
}
void sortLength(char Names[numNames][letters],int order[numNames])
{
	char temp[letters];
	for (int i=0 ; i<=numNames ; ++i)
	{
		int numTemp=0;
		for (int k=i ; k<numNames + 1 ; ++k)
		{
			if (myStringLength(Names[i])> myStringLength(Names[k]))
			{
				myStringCopy(temp, Names[i]);
				numTemp = order[i];
				myStringCopy(Names[i], Names[k]);
				order[i] = order[k];
				myStringCopy(Names[k], temp);
				order[k] = numTemp;
			}
		}
		temp = '\0';
	}
}
void sortAlpha(char Names[numNames][letters],int order[numNames])
{
	char temp[letters];
	for (int i=0 ; i<numNames ; ++i)
	{
		int numTemp=0;
		for (int k=i ; k<numNames +1 ; ++k)
		{
			if (myStringCompare(Names[i], Names[k]) > 0)
			{
				myStringCopy(temp, Names[i]);
				numTemp = order[i];
				myStringCopy(Names[i], Names[k]);
				order[i] = order[k];
				myStringCopy(Names[k], temp);
				order[k] = numTemp;
			}
		}
		temp = '\0'
	}
}
void output2File(char Names[numNames][letters],int order[numNames],char outputFile[])
{
	fstream fp2;
	fp2.open(outputFile);
	for(int r=0;r<numNames;r++)
	{
		fp2 <<order[r]<< Names[r];
	}
	fp2.close();
}
	
