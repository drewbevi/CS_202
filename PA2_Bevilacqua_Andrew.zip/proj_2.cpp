//Andrew Bevilacqua CS202-1001 Lab Section 2
//This program is used to rent a car given a text file with a list of a cars year, make, model, price, and availablity
#include <iostream>
#include <fstream>
//Permitted constants
const int numCars=4;
const int maxSize=10;
using namespace std;
struct RentalCar //info per car
{
	int year;
	char make[maxSize];
	char model[maxSize];
	float price;
	bool available;
};
size_t myStringLength(const char *str);
int myStringCompare(const char *str1,const char *str2);
char *myStringCopy(char *dest,char *source);
char *myStringCat(char *dest,char *source);
void getInfo(char fileName[],RentalCar cars[]);//Option 1
void printCars(RentalCar cars[],int index[numCars]);//Option 2
void output2File(RentalCar cars[],char outputFile[]);//Option 3
void ascendingPrice(RentalCar cars[numCars]);//Option 4
void carEstimate(RentalCar cars[],int n, int index[]);//Option 5
void rentAcar(RentalCar cars[],int n,int indexNum,int index[]);//Option 6
int main()
{
	RentalCar cars[numCars];
	int cmd=0, index[]={0,1,2,3,4},n=0,indexNum=0;
	char fileInput[30];
	do
	{
		cout << "This program will help you get the car of your dreams!" << endl<<"...if it's available..."<<endl;
		cout << "1. Enter an input file."<<endl;
		cout << "2. Print list of cars."<<endl;
		cout << "3. Output data to a file."<<endl;
		cout << "4. Sort cars based on price."<<endl;
		cout << "5. Check to see if a car is available."<<endl;
		cout << "6. Which car would you like to rent?"<<endl;
		cout << "7. Exit"<<endl;
		cout << "Enter a command: ";
		cin >> cmd;
		cout << endl;
		switch(cmd)
		{
			case 1: cout << "Enter a file name:";
				cin >> fileInput;
				getInfo(fileInput,cars);
				break;
			case 2: cout << "Here is a list of cars:" << endl;
				printCars(cars,index);
				break;
			case 3: cout << "Enter an output file name:";
				cin >> fileInput;
				output2File(cars,fileInput);
				break;
			case 4:	cout << "Cars sorted by ascending price:"<<endl;
				ascendingPrice(cars);
				printCars(cars,index);
				break;
			case 5: cout<<"How many days would you like to rent a car?"<<endl;
				cin >>n;
				carEstimate(cars,n,index);
				break;
			case 6: cout << "Which car would you like to rent?"<<endl;
				cin >> indexNum;
				cout << "How long would you like to rent the "<< cars[indexNum].make
				<<" "<< cars[indexNum].model <<" for?" << endl;
				cin >> n;
				rentAcar(cars,n,indexNum,index);
				break;
			case 7:
				break;
				
		}
	}
	while(cmd!=7);
	return 0;
}
size_t myStringLength(const char *str)
{
	int i=0;
	for(i;str[i]!='\0';i++)
	{
	}
	return i;
}
//returns 1 if 1st string is greater 
//returns -1 if 2nd string is greater 
//returns 0 if strings are equal
int myStringCompare(const char *str1,const char *str2)
{
	while(*str1 != '\0' && *str2 != '\0')
	{
		if(*str1==*str2)
			return 0;
		if(*str1>*str2)
			return 1;
		if(*str1<*str2)
			return -1;
		str1++;
		str2++;
	}
}
char *myStringCopy(char *dest,char *source)
{
	char *result;
	while(*source != '\0')
	{
		*dest = *source;
		*result =*dest;
		dest++;
		source++;
		result++;
	}
	return result;
}
char *myStringCat(char *dest,char *source)
{
	char *result = dest;
	while(*source!='\0')
	{
		if(*dest!='\0')
			dest++;
		dest = source;
		dest++;
		source++;
	}
	dest='\0';
	return result;
}
//Option 1:Input a file
void getInfo(char fileName[],RentalCar cars[])
{
	ifstream fp;
	fp.open(fileName);
	while(!fp.eof())
	{
		for(int i=0;i<=numCars;i++)
		{
			fp >> cars[i].year >> cars[i].make >> cars[i].model >> cars[i].price >> cars[i].available;
		}
	}
	fp.close();
	cout << endl;
}
//Option 2:Print list of cars to screen
void printCars(RentalCar cars[],int index[numCars])
{
	for(int i=0;i<=numCars;i++)
	{
		cout << "[" << index[i] << "]:";
		cout << cars[i].year << " "; 
		cout << cars[i].make << " ";
		cout << cars[i].model << ", ";
		cout <<"$" << cars[i].price << " per day, ";
		if(cars[i].available==true)
			cout << "Available: True" << endl;
		else
			cout << "Available: False" << endl;
	}
	cout<<endl;
}
//Option 3:Output list of cars to a seperate file
void output2File(RentalCar cars[],char outputFile[])
{
	fstream fp2;
	fp2.open(outputFile);
	for(int i=0;i<numCars;i++)
	{
		fp2 << cars[i].year << " "<<endl; 
		fp2 << cars[i].make << " "<<endl;
		fp2 << cars[i].model << " "<<endl;
		fp2 << cars[i].price << " "<<endl;
		fp2 << cars[i].available<<endl;
	}
	fp2.close();
	cout << endl;
}
//Option 4:Sort cars in ascending price
void ascendingPrice(RentalCar cars[numCars])
{
	RentalCar temp;
	for(int k=0;k<4;k++)
	{
		for(int i=0;i<4;i++)
		{
			if(cars[i].price > cars[i+1].price)
			{
				temp=cars[i];
				cars[i]=cars[i+1];
				cars[i+1]=temp;
			}
		}
	}
}
//Option 5:Gives and estimate of the price of a car based on its availablity and price per day
void carEstimate(RentalCar cars[],int n, int index[])
{
	ascendingPrice(cars);
	float totalCost=0.0;
	for(int i=0;i<numCars;i++)
	{
		totalCost=cars[i].price *n;
		if(cars[i].available == true)
		{
			cout << "[" << index[i] << "]:";
			cout << cars[i].year << " "; 
			cout << cars[i].make << " ";
			cout << cars[i].model << " ,";
			cout << "Total Cost: $"<< totalCost<<endl;
		}
	}
	cout<<endl;
}
//Option 6:Rents a car to the user no longer making the car available
void rentAcar(RentalCar cars[],int n,int indexNum,int index[])
{
	float totalCost=0;
	if(cars[indexNum].available == false)
	{
		cout << "ERROR: Car is currently unavailable." << endl;
	}
	else if(cars[indexNum].available == true && cars[indexNum].available == true)
	{
		cout<<"Congratualtions! You are now a proud part-time owner of a "
		<< cars[indexNum].make <<" "<<cars[indexNum].model<<"."<<endl;
		cout << "Your car has been rented for "<< n << " days." <<endl;
		totalCost=cars[indexNum].price * n;
		cout << "Total cost for the car rental is : $"<<totalCost<<endl;
		cars[indexNum].available=false;
	}
	cout<<endl;
}

