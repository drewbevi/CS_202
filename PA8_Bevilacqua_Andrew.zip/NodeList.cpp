#include "NodeList.h"
using namespace std;
NodeList::NodeList()//(1)
{
	m_head = NULL;
}
NodeList::NodeList(size_t count, const DataType & value)//(2)
{
	Node* next = NULL;
	Node* temp = NULL;
	for(size_t i=0;i<=count;i++)
	{
		temp = new Node(value, next);
		next = temp;
	}
	m_head = temp;
}
NodeList::NodeList(const NodeList & other)//(3)
{
	Node *temp = other.m_head;
	while(temp != NULL)
	{
		if(temp!=m_head)
		{
			m_head = new Node(*temp);
		}
	}
}
NodeList::~NodeList()//(4)
{
	delete[] m_head;
}
NodeList & NodeList::operator= (const NodeList & rhs)//(5)
{
	if(this != &rhs)
	{
		m_head = rhs.m_head;
	}
	return *this;
}
Node * NodeList::front()//(6)
{
	if(m_head == NULL)
	{
		return NULL;
	}
	else
	{
		return m_head;
	}
}
Node * NodeList::back()//(7)
{
	if(m_head == NULL)
	{
		return NULL;
	}
	else//How to get to the last element?  continue throughout next until NULL? how
	{
	}
}
Node * NodeList::find(const DataType & target,Node * & previous,const Node * start)//(8)
{
	Node * temp = m_head;
	start = NULL;
	previous = NULL;
	while(m_head !=NULL)
	{
		if(temp->data()==target)
		{
			previous = temp->m_next;
			return temp;
		}
	}	
	return NULL;
}
Node * NodeList::insertAfter(const DataType & target,const DataType & value)//(9)
{
	Node * temp = m_head;
	while(m_head !=NULL)
	{
		if(temp->data()==target)
		{
			temp->m_data = value;
			return temp;
		}
	}
	return NULL;
}
Node * NodeList::insertBefore(const DataType & target,const DataType & value)//(10)
{
	Node * temp = m_head;
	//DataType* targetTemp = target; 
	while(m_head !=NULL)
	{
		if(temp->data()==target)
		{
			temp->m_data = new Node(value);
			m_head = temp
			return temp;
		}
	}
	return NULL;
}
Node * NodeList::erase(const DataType & target)//(11)
{
	Node * temp = m_head;
	while(m_head !=NULL)
	{
		if(temp->data()==target)
		{
			Node * next = temp->m_next;
			delete temp;
			return next;
		}
	}
	return NULL;
}
DataType & NodeList::operator[] (size_t position)//(12a)
{
	Node *temp = m_head;
	for(size_t i=0;i<=position;i++)
	{
		temp = temp->m_next;	
	}
	return temp->data();
}
const DataType & NodeList::operator[] (size_t position) const //(12b)
{
	Node *temp = m_head;
	for(size_t i=0;i<=position;i++)
	{
		temp = temp->m_next;		
	}
	return temp->data();
}
size_t NodeList::size()const//(13)
{
	Node *temp = m_head;//Continue to get an Seg fault. Bc the cout does not know when the nodelist stops?
	size_t count = 0;
	while(temp!=NULL)
	{
		temp = temp->m_next;
		++count;
	}
	return count;
}
bool NodeList::empty()const//(14)
{
	if(m_head==NULL)
		return true;
	else
		return false;
}
void NodeList::clear()//(15)
{
	delete[] m_head;
}
ostream & operator<<(ostream & os,const NodeList & nodeList)//(i)
{
	
	size_t size = nodeList.size();
	for(size_t i = 0;i< size;i++)
	{
		os<<i<<": "<<nodeList[i]<<endl;
	}
	return os;
}						
