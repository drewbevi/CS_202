#include "ArrayList.h"
using namespace std;
ArrayList::ArrayList()//(1)
{
	m_size = 0;
	m_maxsize = 0;
	m_array = NULL;
}
ArrayList::ArrayList(size_t count, const DataType & value)//(2)
{
	m_size = count;
	m_maxsize = count + 1;//maxsize > size soooo plus one?
	m_array = new DataType[count];
	for(size_t i = 0; i<= count;i++)
	{
		m_array[i]=value;
	}
}
ArrayList::ArrayList(const ArrayList & other)//(3)
{
	m_array = new DataType[other.m_size];
	m_size = other.m_size;
	m_maxsize = other.m_maxsize;
	for(size_t i = 0; i<= other.m_size;i++)
	{
		m_array[i]=other.m_array[i];
	}
}
ArrayList::~ArrayList()//(4)
{
	delete[] m_array;
}
ArrayList& ArrayList:: operator=(const ArrayList & rhs)//(5)
{
	if(this != &rhs)
	{
		delete[] m_array;
		m_array = rhs.m_array;//moved m_array from the bottom to the top...
		m_size = rhs.m_size;
		m_maxsize =rhs.m_maxsize;
		
		//ArrayList(rhs);
	}
	return *this;
}
DataType* ArrayList:: front()//(6)
{
	if(m_array != NULL)
	{
		for(size_t i = 0;i<= m_size;i++)
		{
			if(m_array[i].checkValid()==true)//uses method found in DataTypes class
			{
				return &m_array[i];
			}
		}
	}
	return NULL;
}
DataType* ArrayList:: back()//(7)
{
	if(m_array != NULL)
	{
		for(size_t i = m_size;i>=0;i--)
		{
			if(m_array[i].checkValid()==true)//uses method found in DataTypes class
			{
				return &m_array[i];
			}
		}
	}
	return NULL;
}
DataType* ArrayList:: find(const DataType & target, DataType*& previous, const DataType* start)//(8)
{
	previous=NULL;
	start = NULL;
	for(size_t i=0; i <= m_size;i++)
	{
		if(m_array[i].checkValid()==true&&m_array[i]==target)
		{
			
			previous=&m_array[i-1];
			return &m_array[i];
		}
	}
	return NULL;
}
DataType * ArrayList::insertAfter(const DataType & target,const DataType & value)//(9)
{
	for(size_t i=0; i <= m_size+1;i++)
	{
		if(m_array[i].checkValid()==true&&m_array[i]==target)
		{
			DataType* listTemp= new DataType[m_maxsize];
			if(m_array[i+1].checkValid())
			{
				listTemp[i+1]=value;
				return listTemp;
			}
			else
			{
				return NULL;
			}
		}
	}
	return NULL;
}
DataType * ArrayList::insertBefore(const DataType & target,const DataType & value)//(10)
{
	for(size_t i=0; i <= m_size+1;i++)
	{
		if(m_array[i].checkValid()==true&&m_array[i]==target)
		{
			DataType* listTemp= new DataType[m_maxsize];
			if(m_array[i-1].checkValid())
			{
				listTemp[i-1]=value;
				return listTemp;
			}
			else
			{
				return NULL;
			}
		}
	}
	return NULL;
}
DataType * ArrayList::erase(const DataType & target)//(11)
{
	for(size_t i=0; i <= m_size+1;i++)
	{
		if(m_array[i].checkValid()==true&&m_array[i]==target)
		{
			if(m_array[i+1].checkValid()==false)
			{
				return NULL;
			}
			else
			{
				//delete temp;
				return &m_array[i+1];
			}
		}
	}
	return NULL;
}
DataType & ArrayList::operator[] (size_t position)//(12)
{
	return m_array[position];
}
size_t ArrayList::size()const//(13)
{
	return m_size;
}
bool ArrayList::empty() const//(14)
{
	if(m_array==NULL)
	{
		return true;
	}
	return false;
}
void ArrayList::clear()//(15)
{
	delete[] m_array;
}
ostream& operator<<(ostream & os, const ArrayList & arrayList)//(i)
{
	size_t size = arrayList.size();
	for(size_t i=0;i < size;i++)
	{
		os<<i<<" : "<<arrayList.m_array[i]<<endl;
	}
	return os;
}
void ArrayList::resize(size_t count)//(16)
{
}
