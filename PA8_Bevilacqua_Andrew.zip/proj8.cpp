#include <iostream>

#include "ArrayList.h"
#include "NodeList.h"
using namespace std;
int main(){

  /* Your test driver code here *///What is that tho??

	DataType d1(1,2.0);
	DataType d2(2,13.0);
	DataType d3(4,6.0);
	DataType d4(5,4.0);
	DataType d5(3,3.0);

	NodeList testNode(5,d1);
	cout<<"assign test"<<endl;
	testNode[3] = d4;
	testNode[4] = d2;
	cout<<testNode<<endl;
	cout<<"insert before"<< endl;
	testNode.insertBefore(d2,d4);
	cout<<testNode<<endl;
  /*I dont know what else to write, is it just a test of all of the functions
  return 0;

}
