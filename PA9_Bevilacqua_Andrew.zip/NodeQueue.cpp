#include "NodeQueue.h"
NodeQueue::NodeQueue()//(1)
{
	m_front = NULL;
	m_back = NULL;
}
NodeQueue::NodeQueue(size_t size, const DataType & value)//(2)
{
	m_front = NULL;
	m_back = NULL;
	for(size_t i = 0;i<=size;i++)
	{
		push(value);
	}
}
NodeQueue::NodeQueue(const NodeQueue & other)//(3)
{
	m_front = NULL;
	m_back = NULL;
	Node* curr = other.m_front;
	while(curr != NULL)
	{
		push(curr->data());
		curr = curr->m_next;
	}
}
NodeQueue::~NodeQueue() //(4)
{
	Node* curr = m_front;
	while(curr != NULL)
	{
		delete curr;
		curr = curr->m_next;
	}
}
NodeQueue& NodeQueue::operator= (const NodeQueue & rhs) //(5)
{
	if(this != &rhs)
	{
		NodeQueue(rhs);
	}
	return *this;
}
DataType & NodeQueue::front()//(6a)
{
	return m_front->data();
}
const DataType & NodeQueue::front() const //(6b)
{
	return m_front->data();
}
DataType & NodeQueue::back()//(7a)
{
	return m_back->data();
}
const DataType & NodeQueue::back() const //(7b)
{
	return m_back->data();
}
void NodeQueue::push(const DataType & value)//(8)
{
	if(size() != ARRAY_MAX)
	{
		Node* temp = new Node(value);
		if(!empty())
		{
			m_back->m_next = temp;
			m_back = temp;
		}
	}
}
void NodeQueue::pop() //(9)
{
	if(size() != ARRAY_MAX)
	{
		Node* curr = m_front;
		if(!empty())
		{
			delete curr;
			curr = curr->m_next;
		}
	}
}
size_t NodeQueue::size() const//(10)
{
	Node* curr = m_front;
	size_t count = 0;
	while(curr != NULL)
	{
		curr = curr-> m_next;
		++count;
	}
	return count;
}
bool NodeQueue::empty() const//(11)
{
	if(m_front == NULL)
		return true;
	return false;
}
bool NodeQueue::full() const//(12)
{
	if(!empty())
		return true;
	return false;
}
void NodeQueue::clear()//(13)
{
	Node* curr =m_front;
	Node* next =NULL;
	while(curr != NULL)
	{
		next = curr;
		curr = curr->m_next;
		delete next;
	}
	m_front =NULL;
	m_back = NULL;
}
void NodeQueue::serialize(std::ostream & os) const//(14)
{
	Node* curr = m_front;
	int i=0;
	while(curr!=NULL)
	{
		os<<i<<": "<<curr->data()<<endl;
		curr = curr->m_next;
		++i;
	}
}
ostream & operator<<(ostream & os,const NodeQueue & nodeQueue)//(i)
{
	nodeQueue.serialize(os);
	return os;
}
