#include <iostream>
using namespace std;
#include "DataType.h"
#include "ArrayQueue.h"
#include "NodeQueue.h"
int main()
{
	DataType d1(1, 2.0),d2(2,13.2);

	cout<<"ARRAYQUEUE"<<endl<<endl;

	ArrayQueue aQ_def;
	cout<<"Default CTOR"<<endl<<endl;
	cout<< aQ_def <<endl;
	cout<<"Parameterized CTOR"<<endl<<endl;
	ArrayQueue aQ(3, d1);
	cout<< aQ <<endl;
	cout<<"Copy CTOR"<<endl<<endl;
	ArrayQueue aQ_copy(aQ);
	cout<<aQ_copy<<endl;
	cout<<"Assignment operator(=)"<<endl<<endl;
	ArrayQueue aQ_assign;
	aQ_assign = aQ;
	cout<<aQ_assign<<endl;
	cout<<"Push method"<<endl<<endl;
	aQ.push(d2);
	cout<<aQ<<endl;
	cout<<"Pop method"<<endl<<endl;
	aQ_assign.pop();
	cout<<aQ_assign<<endl;

	cout<<"NODEQUEUE"<<endl<<endl;

	NodeQueue nQ_def;//declare NodeQueue default ctor
	cout<<"Default CTOR"<<endl<<endl;
	cout<< nQ_def <<endl;
	cout<<"Parameterized CTOR"<<endl<<endl;
	NodeQueue nQ(3, d1);//declare NodeQueue parameterized ctor
	cout<< nQ <<endl;
	cout<<"Copy CTOR"<<endl<<endl;
	ArrayQueue nQ_copy(nQ);//declare NodeQueue copy ctor
	cout<<nQ_copy<<endl;
	cout<<"Assignment operator(=)"<<endl<<endl;
	NodeQueue nQ_assign;//declare NodeQueue assignment object
	nQ_assign = nQ;
	cout<<nQ_assign<<endl;
	cout<<"Push method"<<endl<<endl;
	nQ.push(d2);//push DataType 2 into Parameterized NodeQueue
	cout<<nQ<<endl;
	cout<<"Pop method"<<endl<<endl;
	nQ_assign.pop();//pop DataType 1 from assignment object
	cout<<nQ_assign<<endl;
	return 0;
}
