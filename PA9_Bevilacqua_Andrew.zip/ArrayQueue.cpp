#include "ArrayQueue.h"
ArrayQueue::ArrayQueue()//(1)
{
	m_front = 0;
	m_back = 0;
	m_size = 0;
}
ArrayQueue::ArrayQueue(size_t count, const DataType & value)//(2)
{
	m_front = 0;
	for(size_t i = 0; i<= count;i++)
	{
		push(value);
		++m_size;
	}
}
ArrayQueue::ArrayQueue(const ArrayQueue & other)//(3)
{
	m_size = other.m_size;
	m_front = 0;
	m_back = other.m_back;
	for(size_t i = 0; i<= other.m_size;i++)
	{
		push(other.m_array[i+other.m_front]);
	}
}
ArrayQueue::~ArrayQueue()//(4)
{
	//delete[] m_array;
}
ArrayQueue & ArrayQueue:: operator= (const ArrayQueue & rhs) //(5)
{
	if(this != &rhs)
	{
		m_size = rhs.m_size;
		m_front = 0;
		m_back = rhs.m_back;
		for(size_t i =0; i<=rhs.m_size;i++)
		{
			push(rhs.m_array[i+m_front]);//moved m_array from the bottom to the top...
		}
	}
	return *this;
}
DataType & ArrayQueue::front()//(6a)
{
	return m_array[m_front];
}
const DataType & ArrayQueue::front() const //(6b)
{
	return m_array[m_front];
}
DataType & ArrayQueue::back()//(7a)
{
	return m_array[m_back];
}
const DataType & ArrayQueue::back() const //(7b)
{
	return m_array[m_back];
}
void ArrayQueue::push(const DataType & value)//(8) pushes a value to the back of array
{
	if(m_size != ARRAY_MAX)//what if there are 1000 values?
	{
		if(!empty())
		{
			m_back = (m_back+1)%ARRAY_MAX;
		}
		m_array[m_back] = value;	
		++m_size;
	}
}
void ArrayQueue::pop() //(9) takes out the first element and moves m_front to the next value
{
	if(!empty())
	{
		m_front = (m_front+1)%ARRAY_MAX;
		--m_size;
	}
	
}
size_t ArrayQueue::size() const//(10)
{
	return m_size;
}
bool ArrayQueue::empty() const//(11)  if empty
{
	if(m_array == NULL)
		return true;
	return false;
}
bool ArrayQueue::full() const//(12)   if not empty?
{
	if(m_array != NULL)
		return true;
	return false;
}
void ArrayQueue::clear()//(13)
{
	m_front = 0;
	m_back = 0;
	m_size = 0;

}
void ArrayQueue:: serialize(ostream & os) const//(14)  isnt this a digital??
{
	for(size_t i = 0;i<=m_size;i++)
	{
		os << i << ": " << m_array[i+m_front]<<endl;
	}
}
ostream & operator<<(std::ostream & os,const ArrayQueue & arrayQueue)//(i)
{
	arrayQueue.serialize(os);
	return os;
}
