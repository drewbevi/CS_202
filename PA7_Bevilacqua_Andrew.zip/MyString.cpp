#include "MyString.h"
#include <string.h>
#include <ostream>
using namespace std;
MyString::MyString()
{
	m_buffer = NULL;
	buffer_allocate(0);
}
MyString::MyString(const char * str)
{
	m_buffer = NULL;
	m_size = strlen(str);
	buffer_allocate(m_size);
	strcpy(m_buffer , str );
	//cout<< "param-ctor1"<<endl;
}
MyString::MyString(const MyString & other_myStr)
{
	buffer_allocate(other_myStr.m_size);
	//cout<< "copy-ctor1"<<endl;
	strcpy(m_buffer,other_myStr.m_buffer);
}
MyString::~MyString()
{
	delete [] m_buffer;
}
size_t MyString::size() const//length of string including null value
{
	return strlen(m_buffer)+1;
}
size_t MyString::length() const//length not including null value
{
	return strlen(m_buffer);
}
const char* MyString::c_str() const
{
	char *string = new char[1];
	string[0]='\0';
	return string;
} 
bool MyString::operator== (const MyString & other_myStr) const
{
	if(strcmp(m_buffer,other_myStr.m_buffer)==0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
MyString & MyString::operator= (const MyString & other_myStr)
{
	if(this == &other_myStr)//checks if the two strings are the same
	{			//If so, return this without modifying it
		return *this;
	}
	else			//if strings are different, copy one string to another
	{
		buffer_deallocate();
		MyString(other_myStr);
		return *this;
	}
}
MyString MyString::operator+ (const MyString & other_myStr) const
{
	MyString temp; //create a new object to house the added data values of this and other
	temp.m_size = m_size + other_myStr.m_size;
	temp.m_buffer = new char [temp.m_size];
	strcpy(temp.m_buffer,m_buffer);
	strcat(temp.m_buffer,other_myStr.m_buffer);//add the string in other to the end of m_buffer(now known as temp)
	return temp;
}
char & MyString::operator[] (size_t index)//allows access to specific element?
{
	return m_buffer[index];
}
const char & MyString::operator[] (size_t index) const//allows access to specific element?
{
	return m_buffer[index];
}
ostream & operator<<(ostream & os, const MyString & myStr)
{
	for(size_t i=0;i<myStr.m_size;i++)
	{
		os << myStr.m_buffer[i];
	}
	os << endl << "The length of the string is: " << myStr.m_size <<endl;
	return os;
}
void MyString::buffer_deallocate()
{
	//cout<<"deallocate test"<<endl;
	if(m_buffer == NULL)
	{
		return;
	}
	else if(m_buffer!= NULL)
	{
		delete [] m_buffer;
		m_buffer = NULL;
		m_size = 0;
	}
}
void MyString::buffer_allocate(size_t size)
{
	m_size = size;
	if(m_buffer == NULL)
	{
		//buffer_deallocate();
		m_buffer = new char[m_size+1];//+1 for NULL value
		//cout<<"allocate success"<<endl;
	}
}
