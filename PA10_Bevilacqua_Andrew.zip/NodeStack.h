#ifndef NODESTACK_H_
#define NODESTACK_H_
#include <iostream>
#include <cstdlib>
using namespace std;
template <class T> class NodeStack;
template <class T> ostream & operator<<(ostream & os,const NodeStack<T> & nodeStack);
class Node
{

  friend class NodeStack<T>;  //allows direct accessing of link and data from class NodeList

  public:
    Node() :
	  m_next( NULL )
	{
	}
	Node(const DataType & data, Node * next = NULL) :
	  m_next( next ),
	  m_data( data )
	{
	}
	Node(const Node & other) :
	  m_next( other.m_next ),
	  m_data( other.m_data )
	{
	}
	
    DataType & data(){  //gets non-const reference, can be used to modify value of underlying data
      //return const_cast<DataType &>(static_cast<const Node &>(*this).getData());  //an alternative implementation, just for studying reference
	  return m_data;
    }
    const DataType & data() const{  //gets const reference, can be used to access value of underlying data
      return m_data;
    }

  private:
    Node * m_next; 						
    T m_data;
};
template <class T>
class NodeStack
{
	friend ostream & operator<<(ostream & os,const NodeStack<T> & nodeStack);//(i)
	public:
	NodeStack();//(1)
	NodeStack(size_t count, const T & value);//(2)
	NodeStack(const NodeStack<T> & other);//(3)
	~NodeStack();//(4)
	NodeStack<T> & operator= (const NodeStack<T> & rhs);//(5)
	T & top();//(6a)
	const T & top() const;//(6b)
	void push(const T & value);//(7)
	void pop();//(8)
	size_t size() const;//(9)
	bool empty() const;//(10)
	bool full() const;//(11)
	void clear();//(12)
	void serialize(ostream & os); const//(13)
	private:
	Node<T> * m_top;
};
#endif
template <class T>
NodeStack<T>::NodeStack()//(1)
{
	m_top = NULL;
}
template <class T>
NodeStack<T>::NodeStack(size_t count, const T & value)//(2)
{
	m_top = NULL;
	for(size_t i = 0;i<=count;i++)
	{
		push(value);
	}
}
template <class T>
NodeStack<T>::NodeStack(const NodeStack<T> & other)//(3)
{
	size_t size = other.size();
	m_top = NULL
	Node<T>* curr = other.m_top;
	for(size;size <=0;size--)
	{
		curr = curr->m_next;
		push(curr ->data());
	}
}
template <class T>
NodeStack<T>::~NodeStack()//(4)
{
	clear();
}
template <class T>
NodeStack<T> & NodeStack<T>::operator= (const NodeStack<T> & rhs)//(5)
{
	if(this != &rhs)
	{
		clear();
		NodeStack(rhs);
	}
	return *this;
}
template <class T>
T & NodeStack<T>::top()//(6a)
{
	return m_top->data();
}
template <class T>
const T & NodeStack<T>::top() const//(6b)
{
	return m_top->data();
}
template <class T>
void NodeStack<T>::push(const T & value)//(7)
{
	if(!empty())
	{
		m_top = new Node<T>(value,m_top)//calling the Node copy ctor
	}
	else
	{
		m_top = new Node<T>(value);//calling the param ctor
	}
}
template <class T>
void NodeStack<T>::pop()//(8)
{
	if(!empty())
	{
		Node<T>* temp  = m_top;
		delete temp;
		m_top = m_top->m_next;
	}
}
template <class T>
size_t NodeStack<T>::size() const//(9)
{
	Node<T>* curr = m_top;
	size_t count = 0;
	while(curr != NULL)
	{
		curr = curr-> m_next;
		++count;
	}
	return count;
}
template <class T>
bool NodeStack<T>::empty() const//(10)
{
	if(m_top==NULL)
		return true;
	return false;
}
template <class T>
bool NodeStack<T>::full() const//(11)
{
	return false;//can there even be a max size for the data value??
}
template <class T>
void NodeStack<T>::clear()//(12)
{
	while(m_top)
	{
		pop();
		m_top = m_top->m_next;
	}
}
template <class T>
void NodeStack<T>::serialize(std::ostream & os) const//(13)
{
	Node<T>* curr = m_top;
	size_t i = size();
	while(curr!=NULL)
	{
		os<<i<<": "<<curr->data()<<endl;
		curr = curr->m_next;
		--i;
	}
}
template <class T>
ostream & operator<< (ostream & os,const NodeStack<T> & nodeStack)
{
	nodeStack.serialize(os);
	return os;
}
