#ifndef ARRAYSTACK_H_
#define ARRAYSTACK_H_
#include <iostream>
#include <cstdlib>
using namespace std;
const size_t MAX_STACKSIZE = 1000;
template <class T>
class ArrayStack
{
	template <class L>
	friend ostream & operator<<(ostream & os,const ArrayStack<T> & arrayStack);//(i)
	public:
	ArrayStack();//(1)
	ArrayStack(size_t count, const T & value);//(2)
	ArrayStack(const ArrayStack<T> & other);//(3)
	~ArrayStack();//(4)
	ArrayStack<T> & operator= (const ArrayStack<T> & rhs);//(5)
	T & top();//(6a)
	const T & top() const;//(6b)
	void push(const T & value);//(7)
	void pop();//(8)
	size_t size() const;//(9)
	bool empty() const;//(10)
	bool full() const;//(11)
	void clear();//(12)
	void serialize(ostream & os) const;//(13)
	private:
	T m_container[MAX_STACKSIZE];
	size_t m_top;
};
#endif
template <class T>
ArrayStack<T>::ArrayStack()//(1)
{
	m_top = 0;
}
template <class T>
ArrayStack<T>::ArrayStack(size_t count, const T & value)//(2)
{
	m_top = 0;
	for(size_t i = 0; i<count; i++)
	{
		push(value);
	}
}
template <class T>
ArrayStack<T>::ArrayStack(const ArrayStack<T> & other)//(3)
{
	m_top = 0;
	for(size_t i = 0; i<other.size(); i++)
	{
		push(other.m_container[i]);
	}
}
template <class T>
ArrayStack<T>::~ArrayStack()//(4)
{
	//no new data being allocated so no need to delete
}
template <class T>
ArrayStack<T> & ArrayStack<T>::operator= (const ArrayStack<T> & rhs)//(5)
{
	if(this != &rhs)
	{
		clear();
		if(size_t i = 0;i<rhs.size();i++)
		{
			push(rhs.m_container[i]);
		}
	}
	return *this;
}
template <class T>
T & ArrayStack<T>::top()//(6a)
{
	return m_container[m_top - 1];
}
template <class T>
const T & ArrayStack<T>::top() const//(6b)
{
	return m_container[m_top - 1];
}
template <class T>
void ArrayStack<T>::push(const T & value)//(7)
{
	if(!full())
	{
		m_container[m_top++] = value;
	}
}
template <class T>	
void ArrayStack<T>::pop()//(8)
{
	if(!empty())
	{
		m_top--;//no need to delete memory, it gets deleted as stack decreases
	}
}
template <class T>
size_t ArrayStack<T>::size() const//(9)
{
	return m_top;
}
template <class T>
bool ArrayStack<T>::empty() const//(10)
{
	if(m_container == NULL)
		return true;
	return false;
}
bool ArrayStack<T>::full() const//(11)
{
	if(size() >= MAX_STACKSIZE)
	{
		return true;
	}
	return false;
}
template <class T>
void ArrayStack<T>::clear()//(12)
{
	m_top = 0;	
}
template <class T>
void ArrayStack<T>::serialize(ostream & os) const//(13)
{
	size_t size = size();
	for(size_t i = size - 1;i>=0;i--)
	{
		os<<i<<": "<<m_container[i];;
	}
}
template <class T>
ostream & operator<<(ostream & os,const ArrayStack<T> & arrayStack);//(i)
{
	arrayStack.serialize(os);
	return os;
}
