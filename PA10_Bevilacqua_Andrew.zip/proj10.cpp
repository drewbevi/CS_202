#include "ArrayStack.h"
#include "NodeStack.h"
int main()
{

	cout<<"ARRAYQUEUE"<<endl<<endl;

	/*ArrayStack<int> aS_def;
	cout<<"Default CTOR"<<endl<<endl;
	cout<< aS_def <<endl;
	cout<<"Parameterized CTOR"<<endl<<endl;
	ArrayStack<int> aS(3, 1.2);
	cout<< aS <<endl;
	cout<<"Copy CTOR"<<endl<<endl;
	ArrayStack<int> aS_copy(aS);
	cout<<aS_copy<<endl;
	cout<<"Assignment operator(=)"<<endl<<endl;
	ArrayStack<int> aS_assign;
	aS_assign = aS;
	cout<<aS_assign<<endl;
	cout<<"Push method"<<endl<<endl;
	//aS.push();
	cout<<aS<<endl;
	cout<<"Pop method"<<endl<<endl;
	aS_assign.pop();
	cout<<aS_assign<<endl;*/
	return 0;
}
