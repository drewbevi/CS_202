//Andrew Bevilacqua CS202-1001 Lab section 2
//Project 3 header
#ifndef PROJ3_H_
#define PROJ3_H_
const int MAX_SIZE =256;
const int numCars=5;
using namespace std;
class RentalCar
{
	public:
		RentalCar();
		RentalCar(int year,char *make,char *model,float price,bool available);
		void setYear(int year);
		int getYear();
		void setModel(char *model);
		char *getModel();
		void setMake(char *model);
		char *getMake();
		void setPrice(float price);
		float getPrice();
		void setAvailable(bool available);
		bool getAvailable();
		void printCars();
		float estimateCost(int days);
	private:
		int m_year;
		char m_make[MAX_SIZE],m_model[MAX_SIZE];
		float m_price;
		bool m_available;
};
struct RentalAgency
{
	char name[MAX_SIZE];
	int zipcode[5];
	RentalCar inventory[numCars];
};
#endif

