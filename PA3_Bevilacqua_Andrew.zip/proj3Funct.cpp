//Andrew Bevilacqua CS202-101 Lab section 2
//Project 3 functions
#include <iostream>
#include <fstream>
#include "proj3.h"
//Standard string library funtions			
size_t myStringLength(const char *str)
{
	int i=0;
	for(i;str[i]!='\0';i++)
	{
	}
	return i;
}
//returns 1 if 1st string is greater 
//returns -1 if 2nd string is greater 
//returns 0 if strings are equal
int myStringCompare(const char *str1,const char *str2)
{
	while(*str1 != '\0' && *str2 != '\0')
	{
		if(*str1==*str2)
			return 0;
		if(*str1>*str2)
			return 1;
		if(*str1<*str2)
			return -1;
		str1++;
		str2++;
	}
}
char *myStringCopy(char *dest,char *source)
{
	while(*source != '\0')
	{
		*dest++=*source++;
	}
	return dest;

}
char *myStringCat(char *dest,char *source)
{
	char *result = dest;
	while(*source!='\0')
	{
		if(*dest!='\0')
			dest++;
		dest = source;
		dest++;
		source++;
	}
	dest='\0';
	return result;
}
/*
	Class methods
*/
//Default constructor
RentalCar::RentalCar()
{
}
//Get and set functions
void RentalCar::setYear(int year)
{
	m_year = year;
}
int RentalCar::getYear()
{
	return m_year;
}
void RentalCar::setModel(char *model)
{
	myStringCopy(m_model,model);
}
char* RentalCar::getModel()
{
	return m_model;
}
void RentalCar::setMake(char *make)
{
	myStringCopy(m_make,make);
}
char* RentalCar::getMake()
{
	return m_make;
}
void RentalCar::setPrice(float price)
{
	m_price = price;
}
float RentalCar::getPrice() 
{
	return m_price;
}
void RentalCar::setAvailable(bool available)
{
	m_available=available;
}
bool RentalCar::getAvailable()
{
	return m_available;
}
//Parameterized constructor
RentalCar::RentalCar(int year,char *make,char *model,float price,bool available)
{
	setYear(year);
	setMake(make);
	setModel(model);
	setPrice(price);
	setAvailable(available);
}
void RentalCar::printCars()
{
	cout << m_year << " ";
	cout << m_make << " ";
	cout << m_model << " ,";
	cout << "$"<<m_price<<" per day ,";
	cout << "Available: " << boolalpha << m_available << endl;
}
float RentalCar::estimateCost(int days)
{
	float total = 0.0;
	total = days * m_price;
}
/*
	User options
*/
//Input a file
void Option1(RentalAgency *agency)
{
	char fileName[256],*pt_zip;
	RentalCar *carTemp = agency->inventory;
	int *ptZipInt = (*agency).zipcode;
	cout<<"Enter a file name:";
	cin >> fileName;
	ifstream fp;
	fp.open(fileName);
	//while(!fp.eof())
	//{
		for(int i=0;i<3;i++)
		{
			fp >> (*agency).name;
			
			agency++;
			for(int k=0;k<5;k++)
			{
				char zipChar;//takes zipcode number by number
				fp >> zipChar;//input one number into char
				int Temp = (int)zipChar -'0';//change char to int
				*ptZipInt = Temp;//ptZipInt points to agency.zipcode
				ptZipInt++;
			}
			for(int j=0;j<numCars;j++)
			{	
						
				int year;
				char make[20],model[20];
				float price;
				bool available;
				fp >> year >> make >> model >> price >> available;
				carTemp->setYear(year);
				carTemp->setMake(make);
				carTemp->setModel(model);
				carTemp->setPrice(price);
				carTemp->setAvailable(available);
				carTemp++;						
			}
		}
	//}
}
//print
void Option2(RentalAgency *agency)
{
	RentalCar *carTemp=(*agency).inventory;
	int *pt_zip=(*agency).zipcode;
	for(int i=0;i<3;i++)
	{
		cout << (*agency).name << " ";
		agency++;
		for(int j=0;j<5;j++)
		{
			cout << *pt_zip;
			++pt_zip;
		}
		cout<<endl;
		for(int k=0;k<numCars;k++)
		{
			carTemp -> printCars();
			++carTemp;
		}
	}
	cout<<endl;
}
//Est cost of a car
void Option3(RentalAgency *agency)
{
	int agencyInt=0,days=0,carNumber=0;
	float total=0.0;
	RentalCar *carTemp = (*agency).inventory;//points to an array of 5 object RentalCars
	cout<<"Which agency would you like to rent a car from?"<<endl;
	cin >> agencyInt;
	cout<<"Which car would you like to rent?"<<endl;
	cin >> carNumber;
	cout<<"How long would you like to rent?"<<endl;
	cin >> days;
	for(int i=0;i<=agencyInt;i++,agency++)
	{
		RentalCar *carTemp = (*agency).inventory;//points to an array of 5 object RentalCars
		if(i==agencyInt)
		{
			for(int k=0;k<=carNumber;k++,carTemp++)
			{
				if(k==carNumber && (carTemp -> getAvailable()) ==true)//if car is available and if it is the car they selected
				{
					total=carTemp -> estimateCost(days);
					cout<<"Success! The car you chose has been rented. The total price will be $"<<total<<endl;
					carTemp ->setAvailable(false);
					break;
				}
				else 
				{
					cout<<"Sorry, the car you selected is currently unavailable."<<endl;
				}
			}
		}
	}
}
//Prints the most expensive car out of all agencies
void Option4(RentalAgency *agency)
{
	RentalCar *carTemp = (*agency).inventory;//points to an array of 5 object RentalCars
	RentalCar *test=(*agency).inventory;
	for(int i=0;i<3;i++,agency++)
	{
		++test;
		RentalCar *carTemp2 = test;
		for(int k=0;k<numCars;k++)
		{
			if(carTemp ->getPrice() > (carTemp2 ->getPrice()))
			{
				cout << "The most expensive car is:"<<endl;
				carTemp -> printCars();
			}
			else
			{	
				++carTemp;
				++carTemp2;
			}
			break;
		}
		break;
	}
}
//Output to a file
void Option5(RentalAgency *agency)
{
	char fileName[256];
	//int *ptZipInt = (*agency).zipcode;
	char *pt_Name = (*agency).name;
	RentalCar *carTemp = (*agency).inventory;
	cout<<"Enter an output file:";
	cin >>fileName;
	fstream fp;
	fp.open(fileName);
	for(int i=0;i<3;i++,pt_Name++)
	{
		fp << (*pt_Name);
		for(int j=0;j<5;j++)
		{
			fp << (*agency).zipcode;
		}
		for(int k=0;k<5;k++)
		{
			int year= carTemp->getYear();
			char *make= carTemp->getMake();	//assigns variables to the cars data
			char *model= carTemp->getModel();
			float price= carTemp->getPrice();
			bool available= carTemp->getAvailable();
			if((carTemp->getAvailable())==true)
			{
				fp << endl<< year <<" "<< make << " "<< model<< " "<< price <<" " << available <<endl;
			}
			++carTemp;
		}
	}
	cout<<"Success! The available cars have been outputted to your directed file."<<endl;
}
