//Andrew Bevilacqua CS202-1001 Lab Section 2
//This program is used to rent a car given a list of three agencies and five optional cars
#include <iostream>
#include <fstream>
#include "proj3.h"
#include "proj3Funct.cpp"
using namespace std;
void Option1(RentalAgency *agency);
void Option2(RentalAgency *agency);
void Option3(RentalAgency *agency);
void Option4(RentalAgency *agency);
void Option5(RentalAgency *agency);
int main()
{
	RentalAgency carAgency[3];
	int cmd=0, index[]={0,1,2,3,4},n=0,indexNum=0;
	char fileInput[30];
	cout << "This program will help you get the car of your dreams!" << endl<<"...if it's available..."<<endl;
	do
	{
		cout <<"=============="<<endl<<"  Options:"<<endl<<"=============="<<endl;
		cout << "1. Enter an input file."<<endl;
		cout << "2. Print list of cars."<<endl;
		cout << "3. Estimate cost of car."<<endl;
		cout << "4. Most expensive car."<<endl;
		cout << "5. Output available cars to a file."<<endl;
		cout << "6. Exit" <<endl;
		cout << "Enter a command: ";
		cin >> cmd;
		switch(cmd)
		{
			case 1://Input a file
				Option1(carAgency);
				break;
			case 2://Print Agencies and cars
				Option2(carAgency);
				break;
			case 3://Estimate cost of a car
				Option3(carAgency);
				break;
			case 4://Get most expensive car
				Option4(carAgency);
				break;
			case 5://Outputs cars to a file
				Option5(carAgency);
				break;
			case 6://Exit
				break;
			
		}
				
	}
	while(cmd!=6);
	return 0;
}

