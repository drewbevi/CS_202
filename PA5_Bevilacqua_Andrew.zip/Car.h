#include <iostream>
#include <ostream>
#include "Vehicle.h"
#ifndef CAR_H_
#define CAR_H_
const char default_plate[]={"XXXXXXXX"};
using namespace std;
class Car: public Vehicle
{
	public:
		Car();//default constructor
		Car(char *plates, int vin,float *lla);//parameterized constuctor
		void CarCopy(Car & other);
		~Car();
		Car & operator=(Car & other);//Parameters?
		friend ostream & operator<<(ostream & os,const Car & other);
		void printCar(ostream & os);
		//get/set methods
		void setPlates(char * plates);
		char* getPlates();
		void setThrottle(int throttle);
		int getThrottle();
		void Drive(int throttle);
		float move(float *lla);
	private:
		char m_plates[MAX_SIZE];
		int m_throttle;
};
#endif
