#include "Vehicle.h"
int Vehicle::s_idgen=0;
Vehicle::Vehicle()
{
	m_lla[0]=0.0;
	m_lla[1]=0.0;
	m_lla[2]=0.0;
	m_vin = 0;
	s_idgen=1;
	cout<<"Vehicle "<<getVin()<<" :Default-ctor"<<endl;
}
Vehicle::Vehicle(int vin,float * lla)
{
	m_vin = vin;
	setLLA(lla);
	++s_idgen;
	cout<<"Vehicle "<<getVin()<<" :Parametrized-ctor"<<endl;
}
void Vehicle::VehicleCopy(Vehicle & other)
{
	m_lla[0]= other.m_lla[0];
	m_lla[1]= other.m_lla[1];
	m_lla[2]= other.m_lla[2];
	m_vin = other.m_vin;
	++s_idgen;
	cout<<"Vehicle "<<getVin()<<" :Copy-ctor"<<endl;
}
Vehicle::~Vehicle()
{
	cout<<"Vehicle "<<getVin()<<": Dtor"<<endl;
}
void Vehicle::setLLA(float * lla)
{
	for(int i=0;i<=2;i++)
	{
		m_lla[i]=*lla;
		++lla;
	}
}
Vehicle & Vehicle::operator=(Vehicle & other)
{
	if(m_vin != other.m_vin)
	{
		VehicleCopy(other);
	}
	++s_idgen;
	cout<<"Vehicle "<<getVin()<<" :Assignment"<<endl;
	return *this;
}
ostream& operator<<(ostream & os,const Vehicle & other)
{
	os<<"Vehicle "<<other.m_vin<<" @ ["<<other.m_lla[0]<<", "<<other.m_lla[1]<<", "<<other.m_lla[2]<<"]"<<endl;
	return os;
}
void Vehicle::increaseIdgen()
{
	++s_idgen;
}
float* Vehicle::getLLA()
{
	return m_lla;
}
void Vehicle::setVin(int vin)
{
	m_vin=vin;
}
int Vehicle::getVin()
{
	return m_vin;
}
float Vehicle::move(float * lla)
{
	setLLA(lla);
	cout<<"Vehicle "<<getVin()<<" :CANNOT MOVE-I DON'T KNOW HOW"<<endl;
}
int Vehicle::getIdgen()
{
	return s_idgen;
}
