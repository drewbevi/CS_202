#include "Car.h"
#include "Vehicle.cpp"
#include <cstring>
Car::Car()
{
	strcpy(m_plates,default_plate);
	m_throttle = 0;
	cout<<"Car "<<getVin()<<": Default-ctor"<<endl;
}
Car::Car(char *plates, int vin, float *lla)
{
	setLLA(lla);
	setVin(vin);
	setPlates(plates);
	increaseIdgen();
	cout<<"Car "<<getVin()<<": Parametrized-ctor"<<endl;
}
void Car::CarCopy(Car & other)
{
	setPlates(other.m_plates);
	setThrottle(other.m_throttle);
	cout<<"Car "<<getVin()<<": Copy-ctor"<<endl;
	other.increaseIdgen();
}
Car::~Car()
{
	cout<<"Car "<<getVin()<<": Dtor"<<endl;
}
ostream& operator<<(ostream & os,const Car & other)
{
	os<<"Car "<<other.m_vin<<" Plates: "<< other.m_plates <<", Throttle: "<<other.m_throttle<<" @ ["<<other.m_lla[0]<<", "<<other.m_lla[1]<<", "<<other.m_lla[2]<<"]"<<endl;
	return os;
}
Car & Car::operator=(Car & other)
{
	if(m_vin != other.m_vin)
	{
		m_lla[0]= other.m_lla[0];
		m_lla[1]= other.m_lla[1];
		m_lla[2]= other.m_lla[2];
		m_vin = other.m_vin;
		setPlates(other.getPlates());
		m_throttle = other.m_throttle;
	}
	increaseIdgen();
	cout<<"Car "<<m_vin<<" :Assignment"<<endl;
	return *this;
}
void Car::printCar(ostream & os)
{
	os << m_plates <<", Throttle: "<<m_throttle;
}
void Car::setPlates(char *plates)
{
	strcpy(m_plates,plates);
}
char* Car::getPlates()
{
	return m_plates;
}
void Car::setThrottle(int throttle)
{
	m_throttle = throttle;
}
int Car::getThrottle()
{
	return m_throttle;
}
void Car::Drive(int throttle)
{
	setThrottle(throttle);
}
float Car::move(float * lla)
{
	setLLA(lla);
	Drive(75);
	cout<<"Car "<<getVin()<<": Drive to destination, with throttle @ 75"<<endl;
}
