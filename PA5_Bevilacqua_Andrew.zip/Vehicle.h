#include <iostream>
#include <ostream>
#ifndef VEHICLE_H_
#define VEHICLE_H_
const int MAX_SIZE =256;
using namespace std;
class Vehicle
{
	public:
		Vehicle();//default constructor
		Vehicle(int vin,float *lla);//parameterized constructor
		void VehicleCopy(Vehicle & other);
		~Vehicle();
		Vehicle & operator=(Vehicle & other);//Parameters?
		friend ostream & operator<<(ostream & os,const Vehicle & other);
		void increaseIdgen();
		//get/set Methods
		void setLLA(float *lla);
		float* getLLA();
		void setVin(int vin);
		int getVin();
		float move(float *lla);
		static int getIdgen();
	protected:
		float m_lla[3];//lat-long-altitude(holds 3 values)
		int m_vin;//unique VIN number
	private:
		static int s_idgen;//creates unique identifer per new Vehicle object
};
#endif
