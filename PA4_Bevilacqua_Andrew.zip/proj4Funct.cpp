//Andrew Bevilacqua CS202-101 Lab section 2
//Project 4 functions
#include <iostream>
#include <fstream>
#include "proj4.h"
using namespace std;
//Standard string library funtions			
size_t myStringLength(const char *str)
{
	int i=0;
	for(i;str[i]!='\0';i++)
	{
	}
	return i;
}
//returns 1 if 1st string is greater 
//returns -1 if 2nd string is greater 
//returns 0 if strings are equal
int myStringCompare(const char *str1,const char *str2)
{
	while(*str1 != '\0' && *str2 != '\0')
	{
		if(*str1==*str2)
			return 0;
		if(*str1>*str2)
			return 1;
		if(*str1<*str2)
			return -1;
		str1++;
		str2++;
	}
}
char *myStringCopy(char *dest,char *source)
{
	char *temp= dest;
	while(*source != '\0')
	{
		*dest++=*source++;
	}
	*dest='\0';
	return dest;

}
char *myStringCat(char *dest,char *source)
{
	char *result = dest;
	while(*source!='\0')
	{
		if(*dest!='\0')
			dest++;
		dest = source;
		dest++;
		source++;
	}
	dest='\0';
	return result;
}
/*
	Class methods
*/
//Sensor Class
Sensor::Sensor()//default constructor
{
}
Sensor::Sensor(char* type)//Parameterized constructor
{
	setType(type);
	setExtracost(type);
}
void Sensor::SensorCopy(const Sensor & other)
{
	//char *type = other.getType();
	//setType(type);
	m_extracost = other.m_extracost;
}
	//Sensor get/set methods
void Sensor::setType(char *type)
{
	myStringCopy(m_type,type);
	if(*type!='\0')
	{
		if(*type=='g')
		{
			++gps_cnt;
			m_extracost = 5.0;
		}
		if(*type == 'c')
		{
			++camera_cnt;
			m_extracost = 10.0;
		}
		if(*type == 'l')
		{
			++lidar_cnt;
			m_extracost = 15.0;
		}
		if(*type == 'r'&& *type+2 == 'd')
		{
			++radar_cnt;
			m_extracost = 20.0;
		}
		++type;
	}
}
char* Sensor::getType()
{
	return m_type;
}
void Sensor::setExtracost(char* type)//might want to change to +=
{
	if(type=="g")
	{
		m_extracost = 5.0;
	}
	if(type == "c")
	{
		m_extracost = 10.0;
	}
	if(type == "l")
	{
		m_extracost = 15.0;
	}
	if(type == "r"&& type == "d")
	{
		m_extracost = 20.0;
	}
	if(type == '\0')
	{
		m_extracost = 0.0;
	}
}
float Sensor::getExtracost()
{
	return m_extracost;
}
	//Static get/reset methods
int Sensor::gps_cnt=0;
int Sensor::camera_cnt=0;
int Sensor::lidar_cnt=0;
int Sensor::radar_cnt=0;
int Sensor::resetSensors()
{
	gps_cnt=0;
	camera_cnt=0;
	lidar_cnt=0;
	radar_cnt=0;
}
int Sensor::getGPS()
{
	return Sensor::gps_cnt;
}
int Sensor::getCamera()
{
	return Sensor::camera_cnt;
}
int Sensor::getLidar()
{
	return Sensor::lidar_cnt;
}
int Sensor::getRadar()
{
	return Sensor::radar_cnt;
}
	//Sensor Overloading operator
bool operator==( Sensor & car1, Sensor & car2)//check if sensors are the same
{
	if(myStringCompare(car1.getType(),car2.getType())==0)
	{
		if(car1.getGPS()==car2.getGPS())
		{
			if(car1.getCamera()==car2.getCamera())
			{	
				if(car1.getLidar()==car2.getLidar())
				{
					if(car1.getRadar()==car2.getRadar())
					{
						return true;
					}
				}
			}
		}
	}

}
//Car Class
Car::Car()
{
}
Car::Car(int year,char *make,char *model,float baseprice/* + a sensor*/)
{
	setYear(year);
	setMake(make);
	setModel(model);
	setBasePrice(baseprice);
	
}
void Car::CarCopy(const Car & other)
{
	/*setYear(other.m_year);
	setMake(other.m_make);
	setModel(other.m_model);
	setBasePrice(other.m_baseprice);*/
}
	//Car get/set methods		/*These should work*/
void Car::setYear(int year)
{
	m_year = year;
}
int Car::getYear()
{
	return m_year;
}
void Car::setModel(char *model)
{
	myStringCopy(m_model,model);
}
char* Car::getModel()
{
	return m_model;
}
void Car::setMake(char *make)
{
	myStringCopy(m_make,make);
}
char* Car::getMake()
{
	return m_make;
}
void Car::setAvailable(bool available)
{
	m_available=available;
}
bool Car::getAvailable()
{
	return m_available;
}
void Car::setBasePrice(float price)
{
	m_baseprice = price;
}
float Car::getBasePrice()
{
	return m_baseprice;
}
void Car::setOwner(char *owner)
{
	myStringCopy(m_owner,owner);
}
char* Car::getOwner()
{
	return m_owner;
}
	//Car Extra Methods
int Car::totalSensors()
{
	Sensor *sensorTemp;
	int gps=sensorTemp->getGPS();
	int camera=sensorTemp->getCamera();
	int lidar=sensorTemp->getLidar();
	int radar=sensorTemp->getRadar();
	int total=0;
	total = gps + camera + lidar +radar;
	return total;
	
}
float Car::updatePrice()//WIP  gets price based on baseprice and sensor cost
{
	Sensor *sensorTemp;
	float total=(sensorTemp->getExtracost() + getBasePrice());
	return total;
}
void Car::printCars()//WIP  need to print sensors
{
	Sensor *sensorTemp = m_sensor;
	
	cout << m_year << " ";
	cout << m_make << " ";
	cout << m_model << " ,";
	cout << "$"<<m_baseprice<<" per day ,";
	cout << "Sensor(s): "<<sensorTemp->getType();
	/*for(int i=0;i<=2;i++)
	{
		cout<< sensorTemp->getType()<<" ";
		++sensorTemp;
	}*/
	cout << " Available: " << boolalpha << m_available<< " "<<m_owner<<endl;

	
}
float Car::estimateCost(int days)
{
	float price = updatePrice();
	float total = price * days;
	return total;
}
void Car::AddSensor(char* type)//WIP
{
	Sensor *sensorTemp = m_sensor;
	for(int i=0;i<=2;i++)
	{
		sensorTemp->setType(type);
		++sensorTemp;
	}
}
void Car::AddLessee(char *owner)//WIP  idek what a lessee is
{
	if(getOwner()=='\0')
	{
		setOwner(owner);
	}
}
//Agency Class
Agency::Agency()
{
}
	//Agency get/set
void Agency::setName(char *name)
{
	myStringCopy(m_name,name);
}
char *Agency::getName()
{
	return m_name;
}
void Agency::setZipcode(char *zipcode)
{
	myStringCopy(m_zipcode,zipcode);
}
char *Agency::getZipcode()
{
	return m_zipcode;
}
	//Agency Extra methods
Car &Agency::operator[](int k)
{
	Car *carTemp = m_inventory;
	for(int i=0;i=k;i++)
	{
		m_inventory[i];
	}
	return *carTemp;

}
int Agency::allSensors()
{
	Car *carTemp= m_inventory;
	int total = 0;
	for(int i=0;i<=numCars;i++)
	{
		total=total +(carTemp->totalSensors());
		++carTemp;
	}
	return total;
}
void Agency::rentmostExpensive()
{
	int days=0;
	char userInput,n_owner[20];
	Car *carTemp=m_inventory;
	Car *carTemp2=m_inventory;
	++carTemp2;
	for(int k=0;k<numCars;k++)
	{
		if(carTemp ->updatePrice() > (carTemp2 ->updatePrice()))
		{
			if(carTemp->getAvailable() == true)
			{
				cout << "The most expensive car is the " << carTemp->getMake()<<" "<<carTemp->getModel()<<endl;
				cout << "Would yo like to rent it(Y/N)?"<<endl;
				cin >>userInput;
				if(userInput =='Y')
				{
					cout<<"How long would you like to rent the car?"<<endl;
					cin >>days;
					/*cout<<"What name should the car be under?"<<endl;
					cin >> n_owner;*/
					float price = carTemp->estimateCost(days);
					cout<<"Total Price: "<<price<<endl;
					//carTemp->setOwner(n_owner);
				}
				else
				{
					break;
				}
			}
			else
			{
				cout<<"We apologize, but the car is currently unavailable."<<endl;
			}
		}
		else
		{	
			++carTemp;
			++carTemp2;
		}
	}	
}
void Agency::readAllData()//How to input a sensor?
{
	char fileName[256];		
	cout<<"Enter a file name:";
	cin >> fileName;
	ifstream fp;
	fp.open(fileName);
	Car *carTemp =m_inventory;
	fp >> m_name >> m_zipcode;
	while(fp!='\0')
	{
		for(int i=0;i<numCars;i++)
		{
			int year;
			char make[20],model[20],owner[20],type[30];
			float price;
			bool available;
			fp >> year >> make >> model >> price >> type>> available >> owner;
			carTemp->setYear(year);
			carTemp->setMake(make);
			carTemp->setModel(model);
			carTemp->setBasePrice(price);
			carTemp->AddSensor(type);
			carTemp->AddLessee(owner);
			carTemp->setAvailable(available);
			++carTemp;
			//cout<<carTemp<<endl;
			//need to add sensor, 3 sensors per car
		}
		cout << "Your file has been inputed." << endl;	
	}
	fp.close();
}
void Agency::printAllData()
{
	Car *carTemp=m_inventory;
	cout<<m_name<<" "<<m_zipcode<<endl;
	for(int i=0;i<numCars;i++)
	{
		carTemp->printCars();
		++carTemp;

	}
}
void Agency::printAvailableCars()
{
	Car *carTemp= m_inventory;
	for(int i=0;i<numCars;i++,carTemp++)
	{
		if(carTemp -> getAvailable() == true)
		{
			carTemp -> printCars();
		}
		cout<<endl;
	}
}
