#include "proj4Funct.cpp"
using namespace std;
int main()
{
	Agency carAgency;
	int cmd=0;
	cout << "This program will help you get the car of your dreams!" << endl<<"...if it's available..."<<endl;
	do
	{
		cout <<"=============="<<endl<<"  Options:"<<endl<<"=============="<<endl;
		cout << "1. Enter an input file."<<endl;
		cout << "2. Print list of cars."<<endl;
		cout << "3. Total number of car sensors."<<endl;
		cout << "4. Rent most expensive car."<<endl;
		cout << "5. Exit"<<endl;
		cout << "Enter a command: ";
		cin >> cmd;
		switch(cmd)
		{
			case 1://Input a file
			{
				carAgency.readAllData();
				break;
			}
			case 2://Print Agencies and cars
			{
				carAgency.printAllData();
				break;
			}
			case 3://Print total number of sensors
			{
				int total = carAgency.allSensors();
				cout<< "The total number of sensors is: " << total << endl;
				break;
			}
			case 4://Get most expensive car, ask if they want to rent. update Lessee and availablity
			{
				carAgency.rentmostExpensive();
				break;
			}
			case 5://Exit
			{
				break;
			}
		}
				
	}
	while(cmd!=5);
	return 0;
}
