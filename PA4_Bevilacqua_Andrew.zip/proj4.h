//Andrew Bevilacqua CS202-1001 Lab section 2
//Project 4 header
#ifndef PROJ4_H_
#define PROJ4_H_
const int MAX_SIZE =256;
const int numCars=5;
using namespace std;
class Sensor
{
	public:
		Sensor();
		Sensor(char* type);//Parameterized constructor
		void SensorCopy(const Sensor & other);
		void setType(char* type);
		char *getType();
		void setExtracost(char* type);//sets sensor price based on the sensor name
		float getExtracost();
		friend bool operator==( Sensor & car1, Sensor & car2);//overloading operator
		//Static get/reset methods
		static int resetSensors();
		static int getGPS();
		static int getCamera();
		static int getLidar();
		static int getRadar();
	private:
		char m_type[MAX_SIZE];//type of sensor
		float m_extracost;//additional cost fpr sensor (gps = $5.0/day,camera = $10.0/day,lidar = $15.0/day,radar = $20.0/day, no sensor = $0.0/day)
		static int gps_cnt;//keeps track of existing gps sensor
		static int camera_cnt;//keeps track of existing camera sensor
		static int lidar_cnt;//keeps track of existing lidar sensor
		static int radar_cnt;//keeps track of existing radar sensor
};
class Car
{
	public:
		Car();
		Car(int year,char *make,char *model,float baseprice/*need a sensor*/);//Parameterized constructor
		void CarCopy(const Car & other);
		//get/set methods
		void setYear(int year);
		int getYear();
		void setModel(char *model);
		char *getModel();
		void setMake(char *model);
		char *getMake();
		void setAvailable(bool available);
		bool getAvailable();
		void setBasePrice(float price);
		float getBasePrice();
		void setOwner(char *owner);
		char *getOwner();
		//Extra methods
		int totalSensors();//& sensor?
		float updatePrice();
		void printCars();
		float estimateCost(int days);
		void AddSensor(char *type);
		void AddLessee(char *owner);
		//overloading methods   WIP +/-
	private:
		int m_year;
		char m_make[MAX_SIZE],m_model[MAX_SIZE];
		bool m_available;
		float m_baseprice;//price per day(sensor-less)
		float m_finalprice;//price with price of sensor
		char m_owner[MAX_SIZE];
		Sensor m_sensor[3];
};
class Agency
{
	public:
		Agency();
		void setName(char* name);
		char *getName();
		void setZipcode(char *zipcode);
		char *getZipcode();
		void rentmostExpensive();
		int allSensors();
		void readAllData();
		void printAllData();
		void printAvailableCars();
		Car &operator[](int k);
	private:
		char m_zipcode[MAX_SIZE];
		char m_name[MAX_SIZE];
		Car m_inventory[MAX_SIZE];
};
#endif
