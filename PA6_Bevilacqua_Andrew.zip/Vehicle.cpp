#include "Vehicle.h"
Vehicle::Vehicle()
{
	for(int i=0;i<=2;i++)
	{
		m_lla[i]=0.0;
	}
	cout<<"Vehicle :Default-ctor"<<endl;
}
Vehicle::Vehicle(float * lla)
{
	SetLLA(lla);
	cout<<"Vehicle :Parametrized-ctor"<<endl;
}
void Vehicle::VehicleCopy(Vehicle & other)
{
	SetLLA(other.m_lla);
	cout<<"Vehicle  :Copy-ctor"<<endl;
}
Vehicle::~Vehicle()
{
	cout<<"Vehicle : Dtor"<<endl;
}
void Vehicle::SetLLA(float * lla)
{
	for(int i=0;i<=2;i++)
	{
		m_lla[i]=*lla;
		++lla;
	}
}
/*void Serialize(ostream & os)
{
	os<<"Vehicle @ ["<<m_lla[0]<<", "<<m_lla[1]<<", "<<m_lla[2]<<", "<<"]"<<endl;
}*/
Vehicle & Vehicle::operator=(Vehicle & other)
{
	if(this != &other)
	{
		VehicleCopy(other);
	}
	cout<<"Vehicle :Assignment"<<endl;
	return *this;
}
ostream & operator<<(ostream & os,Vehicle & other)
{
	other.Serialize(os);
	return os;
}
float* Vehicle::getLLA()
{
	return m_lla;
}
float Vehicle::Move(float * lla)
{
	SetLLA(lla);
	cout<<"Vehicle :CANNOT MOVE-I DON'T KNOW HOW"<<endl;
}

