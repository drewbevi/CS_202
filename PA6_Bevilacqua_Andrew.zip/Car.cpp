#include "Car.h"
#include "Vehicle.cpp"
#include <cstring>
Car::Car()
{
	m_throttle = 0;
	cout<<"Car : Default-ctor"<<endl;
}
Car::Car(float *lla)
{
	SetLLA(lla);
	cout<<"Car : Parametrized-ctor"<<endl;
}
void Car::CarCopy(Car & other)
{
	setThrottle(other.m_throttle);
	cout<<"Car : Copy-ctor"<<endl;
}
Car::~Car()
{
	cout<<"Car : Dtor"<<endl;
}
Car & Car::operator=(Car & other)
{
	if(this!=&other)
	{
		SetLLA(other.m_lla);
		m_throttle = other.m_throttle;
	}
	cout<<"Car : Assignment"<<endl;
	return *this;
}
/*ostream& operator<<(ostream & os,const Car & other)const
{
	other.Serialize(os);
	return os;
}*/
void Car::Serialize(ostream & os)
{
	os<<"Car: Throttle "<<m_throttle<<" @ ["<<m_lla[0]<<", "<<m_lla[1]<<", "<<m_lla[2]<<", "<<"]"<<endl;

}
void Car::setThrottle(int throttle)
{
	m_throttle = throttle;
}
int Car::getThrottle()
{
	return m_throttle;
}
float Car::move(float * lla)
{
	SetLLA(lla);
	setThrottle(75);
	cout<<"Car:Drive to destination, with throttle @ 75"<<endl;
}
