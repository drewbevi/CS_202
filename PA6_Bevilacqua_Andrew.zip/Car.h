#include <iostream>
#include <ostream>
#include "Vehicle.h"
#ifndef CAR_H_
#define CAR_H_
using namespace std;
class Car: public Vehicle
{
	public:
		Car();//default constructor
		Car(float *lla);//parameterized constuctor
		void CarCopy(Car & other);
		virtual ~Car();
		Car & operator=(Car & other);//Parameters?
		//friend ostream & operator<<(ostream & os,const Car & other)const;
		void printCar(ostream & os);
		//get/set methods
		void setThrottle(int throttle);
		int getThrottle();
		virtual float move(float *lla);
	private:
		int m_throttle;
		virtual void Serialize(ostream & os);
};
#endif
