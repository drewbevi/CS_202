#include <iostream>
#include <ostream>
#ifndef VEHICLE_H_
#define VEHICLE_H_
const int MAX_SIZE =256;
using namespace std;
class Vehicle
{
	public:
		Vehicle();//default constructor
		Vehicle(float *lla);//parameterized constructor
		void VehicleCopy(Vehicle & other);
		virtual ~Vehicle();
		Vehicle & operator=(Vehicle & other);//Parameters?
		friend ostream & operator<<(ostream & os, Vehicle & other);
		//get/set Methods
		void SetLLA(float *lla);
		float* getLLA();
		virtual float Move(float *lla);
	protected:
		float m_lla[3];//lat-long-altitude(holds 3 values)
	private:
		virtual void Serialize(ostream & os)=0;
};
#endif
